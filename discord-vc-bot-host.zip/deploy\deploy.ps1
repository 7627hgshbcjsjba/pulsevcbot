<#
.SYNOPSIS
    Copies the Discord VC Bot to a Linux VM and installs it as a systemd service.

.EXAMPLE
    .\deploy.ps1 -Host 129.146.44.12 -User ubuntu -KeyFile $HOME\.ssh\oracle_vc

.EXAMPLE
    .\deploy.ps1 -Host 129.146.44.12 -User ubuntu -KeyFile $HOME\.ssh\oracle_vc -SetupOnly
#>
[CmdletBinding()]
param(
    [Parameter(Mandatory = $true)][string]$Host,
    [string]$User = 'ubuntu',
    [string]$KeyFile = "$HOME\.ssh\oracle_vc",
    [int]$Port = 22,
    [switch]$SetupOnly,
    [switch]$NoSetup
)

$ErrorActionPreference = 'Stop'

$project = Split-Path -Parent $PSScriptRoot
$remote = "${User}@${Host}"
$appDir = '/home/vcbot/discord-vc-bot'

if (-not (Get-Command ssh -ErrorAction SilentlyContinue)) {
    throw "ssh not found. Install the OpenSSH Client (Windows 10+ optional feature)."
}
if (-not (Get-Command scp -ErrorAction SilentlyContinue)) {
    throw "scp not found. Install the OpenSSH Client (Windows 10+ optional feature)."
}
if (-not (Test-Path -LiteralPath $KeyFile)) {
    throw "SSH key not found: $KeyFile"
}

Write-Host "==> Preparing remote directory on $remote" -ForegroundColor Cyan
ssh -i $KeyFile -p $Port -o StrictHostKeyChecking=accept-new -o ConnectTimeout=20 $remote `
    "sudo mkdir -p $appDir && sudo chown -R $User $appDir /home/vcbot" | Out-Null

if (-not $SetupOnly) {
    Write-Host "==> Uploading project files" -ForegroundColor Cyan
    $files = @(
        'index.js',
        'deploy-commands.js',
        'package.json',
        'package-lock.json',
        '.env',
        '.env.example',
        'README.md'
    )
    foreach ($file in $files) {
        $src = Join-Path $project $file
        if (Test-Path -LiteralPath $src) {
            Write-Host "    $file"
            scp -i $KeyFile -P $Port -o StrictHostKeyChecking=accept-new $src "${remote}:$appDir/" | Out-Null
        }
    }

    $deployDir = Join-Path $project 'deploy'
    if (Test-Path -LiteralPath $deployDir) {
        Write-Host "    deploy/"
        scp -i $KeyFile -P $Port -o StrictHostKeyChecking=accept-new -r $deployDir "${remote}:$appDir/" | Out-Null
    }

    Write-Host "==> Fixing ownership" -ForegroundColor Cyan
    ssh -i $KeyFile -p $Port $remote "sudo chown -R vcbot:vcbot /home/vcbot" | Out-Null
}

if (-not $NoSetup) {
    Write-Host "==> Running setup on the VM" -ForegroundColor Cyan
    ssh -i $KeyFile -p $Port $remote "bash $appDir/deploy/setup-vm.sh"
}

Write-Host ""
Write-Host "Deployed. Live logs:" -ForegroundColor Green
Write-Host "  ssh -i $KeyFile -p $Port $remote `"sudo journalctl -u vc-bot -f`""
Write-Host ""
Write-Host "Update later with:" -ForegroundColor Green
Write-Host "  .\deploy.ps1 -Host $Host -User $User -KeyFile $KeyFile"
