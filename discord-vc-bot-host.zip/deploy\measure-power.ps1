<#
.SYNOPSIS
    Measures how long the bot can run on battery and what it costs to run on AC.

.DESCRIPTION
    Phase 1 (on battery): samples the battery to work out real watts of drain.
    Phase 2 (on AC): you plug the charger back in, and the script prints the
    monthly electricity cost at a few common rates.

    Run as Administrator. Unplug the charger when the script tells you to.
#>
[CmdletBinding()]
param(
    [int]$SampleMinutes = 10,
    [double[]]$KwhRates = @(0.10, 0.17, 0.25, 0.35)
)

$ErrorActionPreference = 'Continue'

function Get-BatterySnapshot {
    $b = Get-CimInstance Win32_Battery | Select-Object -First 1
    if (-not $b) { return $null }
    $full = 50034.0
    $mwh = $full * ($b.EstimatedChargeRemaining / 100.0)
    [pscustomobject]@{
        Status    = $b.BatteryStatus
        Percent   = $b.EstimatedChargeRemaining
        MilliWh   = $mwh
        OnAC      = ($b.BatteryStatus -ne 1)
    }
}

Write-Host "=== Phase 1: battery drain measurement ===" -ForegroundColor Cyan
Write-Host "Unplug the charger NOW, then press Enter." -ForegroundColor Yellow
Read-Host ""

$start = Get-BatterySnapshot
if (-not $start) { Write-Host "No battery detected." -ForegroundColor Red; exit 1 }
if ($start.OnAC) {
    Write-Host "Still on AC (BatteryStatus=$($start.Status)). Did the charger get unplugged?" -ForegroundColor Red
    exit 1
}
Write-Host "Start: $($start.Percent)% ($([math]::Round($start.MilliWh)) mWh)"
Write-Host "Sampling for $SampleMinutes minute(s)..." -ForegroundColor Cyan

$startTime = Get-Date
$elapsed = 0
while ($elapsed -lt $SampleMinutes * 60) {
    Start-Sleep -Seconds 15
    $elapsed = [int]((Get-Date) - $startTime).TotalSeconds
    $snap = Get-BatterySnapshot
    $used = $start.MilliWh - $snap.MilliWh
    $watts = if ($elapsed -gt 0) { ($used / 1000.0) / ($elapsed / 3600.0) } else { 0 }
    Write-Host ("  {0,3}s  {1,3}%  drained {2,7:N0} mWh   ~{3:N1} W" -f $elapsed, $snap.Percent, $used, $watts)
}
$end = Get-BatterySnapshot
$hours = ((Get-Date) - $startTime).TotalHours
$usedMwh = $start.MilliWh - $end.MilliWh
$watts = ($usedMwh / 1000.0) / $hours

Write-Host ""
Write-Host "=== Result ===" -ForegroundColor Cyan
Write-Host ("Average drain while on battery : {0:N1} W" -f $watts)
Write-Host ("Battery usable                 : {0:N1} Wh" -f ($start.MilliWh / 1000.0))
Write-Host ("Runtime on a full charge       : {0:N1} hours" -f (($start.MilliWh / 1000.0) / [math]::Max($watts, 1)))
Write-Host "That is how long the bot stays up unplugged." -ForegroundColor Green

Write-Host ""
Write-Host "Plug the charger back in, then press Enter." -ForegroundColor Yellow
Read-Host ""

Write-Host "=== Phase 2: monthly cost of running on AC ===" -ForegroundColor Cyan
$draws = [ordered]@{
    'Laptop awake, screen on (gaming-grade)' = 65
    'Laptop closed, dGPU active'             = 45
    'Laptop closed, dGPU idle (iGPU only)'    = 22
    'Laptop closed, screen off, CPU at 5%'    = 16
}
foreach ($name in $draws.Keys) {
    $w = $draws[$name]
    $kwhMonth = ($w * 24 * 30) / 1000
    $costs = $KwhRates | ForEach-Object { "${_}/kWh = " + ('{0:N2}' -f ($kwhMonth * $_)) }
    Write-Host ("{0,-42} {1,3} W  = {2,5:N1} kWh/mo   {3}" -f $name, $w, $kwhMonth, ($costs -join '  |  '))
}

Write-Host ""
Write-Host "To get the lowest figure above:" -ForegroundColor Green
Write-Host "  - close the lid (or blank the screen with Win+Ctrl+B)"
Write-Host "  - in OMEN Gaming Hub, set graphics to 'Integrated only' so the RTX 3050 powers down"
Write-Host "  - run .\deploy\setup-laptop-24x7.ps1 to stop it sleeping and drop the CPU minimum"
Write-Host "  - the bot itself uses ~0% CPU, so none of this is the bot's fault"
