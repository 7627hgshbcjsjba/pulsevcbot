'use strict';

require('dotenv').config({ quiet: true });

const { REST, Routes, SlashCommandBuilder, ChannelType } = require('discord.js');

const token = (process.env.DISCORD_TOKEN ?? '').trim();
const guildId = (process.env.GUILD_ID ?? '').trim() || null;

if (!token) {
  console.error('DISCORD_TOKEN is missing. Copy .env.example to .env and fill it in.');
  process.exit(1);
}

const command = new SlashCommandBuilder()
  .setName('vc')
  .setDescription('Control where the bot sits in voice')
  .addSubcommand((sub) =>
    sub
      .setName('join')
      .setDescription('Join a voice channel (defaults to your channel)')
      .addChannelOption((option) =>
        option
          .setName('channel')
          .setDescription('Voice channel to join')
          .addChannelTypes(ChannelType.GuildVoice, ChannelType.GuildStageVoice),
      ),
  )
  .addSubcommand((sub) => sub.setName('leave').setDescription('Remove the bot from the voice channel'))
  .addSubcommand((sub) => sub.setName('status').setDescription('Show the current voice status'))
  .addSubcommand((sub) =>
    sub
      .setName('move')
      .setDescription('Move the bot to another voice channel')
      .addChannelOption((option) =>
        option
          .setName('channel')
          .setDescription('Voice channel to move into')
          .addChannelTypes(ChannelType.GuildVoice, ChannelType.GuildStageVoice),
      ),
  );

(async () => {
  const rest = new REST({ version: '10' }).setToken(token);
  const body = [command.toJSON()];
  try {
    const application = await rest.get(Routes.oauth2CurrentApplication());
    const applicationId = process.env.DISCORD_CLIENT_ID?.trim() || application.id;
    if (guildId) {
      await rest.put(Routes.applicationGuildCommands(applicationId, guildId), { body });
      console.log(`Registered ${body.length} guild command(s) for ${guildId}.`);
    } else {
      await rest.put(Routes.applicationCommands(applicationId), { body });
      console.log(`Registered ${body.length} global command(s) (up to 1h to appear).`);
    }
  } catch (error) {
    console.error('Registration failed:', error.message);
    process.exit(1);
  }
})();
