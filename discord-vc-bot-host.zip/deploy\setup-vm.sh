#!/usr/bin/env bash
# One-shot setup for a fresh Ubuntu VM (Oracle Cloud / Google Cloud / any VPS).
# Idempotent: safe to re-run.
set -euo pipefail

APP_DIR="/home/vcbot/discord-vc-bot"
SERVICE_FILE="/etc/systemd/system/vc-bot.service"

echo "==> Updating apt and installing base packages"
sudo apt-get update -qq
sudo apt-get install -y -qq git curl ca-certificates

echo "==> Installing Node.js 22 (required by @discordjs/voice >= 22.12)"
node_major=0
if command -v node >/dev/null 2>&1; then
  node_major="$(node -v | cut -d. -f1 | tr -dc '0-9')"
fi
if [ "$node_major" -lt 22 ]; then
  curl -fsSL https://deb.nodesource.com/setup_22.x | sudo -E bash -
  sudo apt-get install -y -qq nodejs
  echo "    Installed Node $(node -v)"
else
  echo "    Node $(node -v) already present, skipping"
fi

echo "==> Creating the vcbot user"
if ! id -u vcbot >/dev/null 2>&1; then
  sudo useradd -m -s /bin/bash vcbot
fi
sudo mkdir -p "$APP_DIR"

echo "==> Fixing ownership so the service user can write node_modules and state.json"
sudo chown -R vcbot:vcbot /home/vcbot

echo "==> Installing dependencies"
if [ -f "$APP_DIR/package.json" ]; then
  sudo -u vcbot bash -c "cd '$APP_DIR' && npm install --omit=dev --no-audit --no-fund"
else
  echo "    WARNING: $APP_DIR/package.json not found. Copy the project files first."
fi

echo "==> Installing the systemd service"
if [ -f "$APP_DIR/deploy/vc-bot.service" ]; then
  sudo cp "$APP_DIR/deploy/vc-bot.service" "$SERVICE_FILE"
else
  echo "    WARNING: vc-bot.service not found in $APP_DIR/deploy"
fi

sudo systemctl daemon-reload
sudo systemctl enable vc-bot >/dev/null 2>&1 || true
sudo systemctl restart vc-bot

echo "==> Waiting for the bot to connect"
sleep 8
if sudo systemctl is-active --quiet vc-bot; then
  echo "    vc-bot is RUNNING"
else
  echo "    WARNING: vc-bot is not active, check the logs below"
fi
sudo journalctl -u vc-bot -n 20 --no-pager || true

cat <<'EOF'

Setup complete.

  Live logs   : sudo journalctl -u vc-bot -f
  Restart     : sudo systemctl restart vc-bot
  Stop        : sudo systemctl stop vc-bot
  Status      : sudo systemctl status vc-bot
EOF
