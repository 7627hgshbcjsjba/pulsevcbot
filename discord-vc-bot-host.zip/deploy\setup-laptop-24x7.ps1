<#
.SYNOPSIS
    Configures this Windows laptop to stay on 24/7 as a Discord bot host, while
    minimising battery wear and heat. Safe to re-run.

.DESCRIPTION
    - Never sleeps or hibernates on AC power
    - Lid close does nothing (screen turns off, bot keeps running)
    - Screen and disk timeouts disabled on AC
    - Hibernation disabled
    - CPU minimum dropped so it is not pinned at max boost all day

    Run as Administrator. Use -Undo to restore Windows defaults.
#>
[CmdletBinding()]
param(
    [switch]$Undo
)

$ErrorActionPreference = 'Continue'

function Test-Admin {
    $identity = [Security.Principal.WindowsIdentity]::GetCurrent()
    (New-Object Security.Principal.WindowsPrincipal($identity)).IsInRole(
        [Security.Principal.WindowsBuiltInRole]::Administrator)
}

if (-not (Test-Admin)) {
    Write-Host "This script needs Administrator rights." -ForegroundColor Red
    Write-Host "Right-click PowerShell -> Run as administrator, then re-run it."
    exit 1
}

$AC = 'SCHEME_CURRENT'
$failures = @()

function Invoke-PowerCfg {
    param([string[]]$Arguments, [string]$Label)
    $output = & powercfg @Arguments 2>&1 | Out-String
    if ($LASTEXITCODE -eq 0) {
        Write-Host "    [ok]   $Label" -ForegroundColor Green
    } else {
        $msg = ($output -split "`r?`n" | Where-Object { $_.Trim() } | Select-Object -First 1)
        Write-Host "    [skip] $Label  ($msg)" -ForegroundColor Yellow
        $script:failures += $Label
    }
}

Write-Host "==> Sleep / hibernate / screen / disk timeouts" -ForegroundColor Cyan
if ($Undo) {
    Invoke-PowerCfg @('/change', 'standby-timeout-ac', '30')     'sleep -> 30 min'
    Invoke-PowerCfg @('/change', 'hibernate-timeout-ac', '60')  'hibernate -> 60 min'
    Invoke-PowerCfg @('/change', 'monitor-timeout-ac', '20')     'screen -> 20 min'
    Invoke-PowerCfg @('/change', 'disk-timeout-ac', '20')        'disk -> 20 min'
} else {
    Invoke-PowerCfg @('/change', 'standby-timeout-ac', '0')      'never sleep'
    Invoke-PowerCfg @('/change', 'hibernate-timeout-ac', '0')   'never hibernate'
    Invoke-PowerCfg @('/change', 'monitor-timeout-ac', '0')      'screen off'
    Invoke-PowerCfg @('/change', 'disk-timeout-ac', '0')         'disk idle off'
}

Write-Host "==> Lid close action" -ForegroundColor Cyan
$lidGuid = '5ca83367-6e45-459f-a27b-476b1d01c936'
$lidValue = if ($Undo) { '1' } else { '0' }
$lidNames = @{ '0' = 'Do nothing'; '1' = 'Sleep'; '2' = 'Hibernate'; '3' = 'Shut down' }
$lidOk = $false
foreach ($setting in @('LIDACTION', $lidGuid)) {
    & powercfg /setacvalueindex $AC SUB_BUTTONS $setting $lidValue 2>&1 | Out-Null
    if ($LASTEXITCODE -eq 0) { $lidOk = $true; break }
}
if ($lidOk) {
    Invoke-PowerCfg @('/setactive', $AC) 'apply power plan'
    Write-Host "    [ok]   lid close action = $lidValue ($($lidNames[$lidValue]))" -ForegroundColor Green
} else {
    Write-Host "    [skip] this model does not expose the lid-close setting." -ForegroundColor Yellow
    Write-Host "           Leave the LID OPEN and turn the screen off manually instead:" -ForegroundColor Yellow
    Write-Host "             - press Win+Ctrl+B to blank the screen (press again to restore)" -ForegroundColor Yellow
    Write-Host "             - or drag brightness to 0 in Settings > System > Display" -ForegroundColor Yellow
    $failures += 'lid close action'
}

Write-Host "==> Hibernation" -ForegroundColor Cyan
if ($Undo) {
    Invoke-PowerCfg @('/hibernate', 'on') 'hibernate enabled'
} else {
    Invoke-PowerCfg @('/hibernate', 'off') 'hibernation disabled'
}

Write-Host "==> CPU boost behaviour" -ForegroundColor Cyan
if (-not $Undo) {
    Invoke-PowerCfg @('/setacvalueindex', $AC, 'SUB_PROCESSOR', 'PROCTHROTTLEMIN', '5') 'CPU minimum 5%'
    Invoke-PowerCfg @('/setactive', $AC) 'apply power plan'
}

Write-Host ""
if ($failures.Count -gt 0) {
    Write-Host "Some settings were not available on this machine:" -ForegroundColor Yellow
    $failures | ForEach-Object { Write-Host "  - $_" -ForegroundColor Yellow }
    Write-Host ""
}

Write-Host "Battery protection for HP Victus (your model)" -ForegroundColor Green
Write-Host "  1. Restart the laptop and press F10 to enter the BIOS."
Write-Host "  2. Go to Advanced > Built-in Device Options (or System Configuration)."
Write-Host "  3. Enable 'Battery Conservation Mode' - this caps charging at 80%."
Write-Host "  4. Also enable 'Adaptive Energy Optimizer' if present."
Write-Host "  5. Save and exit (F10)."
Write-Host ""
Write-Host "With conservation mode on, leaving it plugged in 24/7 is safe: the" -ForegroundColor Green
Write-Host "charger tops up to 80% and stops, so the battery never sits full and" -ForegroundColor Green
Write-Host "never cycles overnight. Keep it on a hard surface - heat, not charging," -ForegroundColor Green
Write-Host "is what actually shortens laptop battery life."
Write-Host ""
Write-Host "Cut the electricity draw (biggest lever on a gaming laptop):" -ForegroundColor Green
Write-Host "  - In OMEN Gaming Hub > Graphics, switch to 'Integrated only' so the"
Write-Host "    RTX 3050 powers down. That alone can halve the idle draw."
Write-Host "  - Close the lid, or blank the screen with Win+Ctrl+B."
Write-Host "  - Keep the 80% charge limit on and leave it plugged in. The charger"
Write-Host "    stops at 80% and does not cycle the battery, so wear is near zero."
Write-Host ""
Write-Host "Measure your real numbers: .\deploy\measure-power.ps1" -ForegroundColor Green
Write-Host "Undo everything:  .\deploy\setup-laptop-24x7.ps1 -Undo"
