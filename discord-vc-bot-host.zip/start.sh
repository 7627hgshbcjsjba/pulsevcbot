#!/bin/sh
# Start the Discord VC bot.
cd "$(dirname "$0")" || exit 1
if [ ! -d node_modules ]; then
  echo "node_modules missing, installing..."
  npm install --omit=dev --no-audit --no-fund
fi
exec node index.js
