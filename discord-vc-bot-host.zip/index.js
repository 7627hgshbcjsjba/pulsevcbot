'use strict';

require('dotenv').config({ quiet: true });

const fs = require('node:fs');
const path = require('node:path');
const { Readable } = require('node:stream');
const {
  Client,
  Events,
  GatewayIntentBits,
  PermissionFlagsBits,
  ChannelType,
  SlashCommandBuilder,
  EmbedBuilder,
} = require('discord.js');
const voice = require('@discordjs/voice');

const CONFIG = {
  token: (process.env.DISCORD_TOKEN ?? '').trim(),
  guildId: (process.env.GUILD_ID ?? '').trim() || null,
  vcChannelId: (process.env.VC_CHANNEL_ID ?? '').trim() || null,
  allowedUsers: (process.env.ALLOWED_USERS ?? '')
    .split(',')
    .map((value) => value.trim())
    .filter(Boolean),
  rejoinOnKick: !/^(false|0|no)$/i.test((process.env.REJOIN_ON_KICK ?? 'true').trim()),
  selfMute: !/^(false|0|no)$/i.test((process.env.SELF_MUTE ?? 'true').trim()),
  silentAudio: !/^(false|0|no)$/i.test((process.env.SILENT_AUDIO ?? 'false').trim()),
  stateFile: process.env.STATE_FILE?.trim() || path.join(__dirname, 'state.json'),
};

const state = {
  guildId: null,
  channelId: null,
  channelName: null,
  connection: null,
  player: null,
  intentionalLeave: false,
  reconnectTimer: null,
  attempts: 0,
};

function log(...args) {
  const stamp = new Date().toISOString().replace('T', ' ').slice(0, 19);
  console.log(`[${stamp}]`, ...args);
}

function loadState() {
  try {
    if (!fs.existsSync(CONFIG.stateFile)) return null;
    const parsed = JSON.parse(fs.readFileSync(CONFIG.stateFile, 'utf8'));
    if (parsed.guildId && parsed.channelId) return parsed;
  } catch (error) {
    log('Could not read state file:', error.message);
  }
  return null;
}

function saveState() {
  if (!state.guildId || !state.channelId) return;
  const payload = {
    guildId: state.guildId,
    channelId: state.channelId,
    channelName: state.channelName,
    savedAt: new Date().toISOString(),
  };
  try {
    fs.writeFileSync(CONFIG.stateFile, JSON.stringify(payload, null, 2));
  } catch (error) {
    log('Could not write state file:', error.message);
  }
}

function clearState() {
  state.guildId = null;
  state.channelId = null;
  state.channelName = null;
  state.attempts = 0;
  try {
    if (fs.existsSync(CONFIG.stateFile)) fs.unlinkSync(CONFIG.stateFile);
  } catch {
    /* ignore */
  }
}

function userAllowed(user) {
  if (CONFIG.allowedUsers.length === 0) return true;
  return CONFIG.allowedUsers.includes(user.id);
}

function ffmpegAvailable() {
  const probe = require('node:child_process').spawnSync('ffmpeg', ['-version'], {
    stdio: 'ignore',
    shell: true,
  });
  return probe.status === 0;
}

function createSilenceStream() {
  const frameBytes = 960 * 2 * 2;
  const frame = Buffer.alloc(frameBytes);
  let timer = null;
  return new Readable({
    read() {
      timer = setTimeout(() => {
        timer = null;
        this.push(frame);
      }, 20);
    },
    destroy(error, callback) {
      if (timer) clearTimeout(timer);
      callback(error);
    },
  });
}

function startSilentAudio(connection) {
  if (!CONFIG.silentAudio) return;
  let prism;
  try {
    prism = require('prism-media');
  } catch {
    log('prism-media unavailable, skipping silent audio');
    return;
  }
  try {
    const encoder = new prism.opus.Encoder({ rate: 48000, channels: 2, frameSize: 960 });
    const resource = voice.createAudioResource(createSilenceStream().pipe(encoder), {
      inputType: voice.StreamType.Opus,
    });
    const player = voice.createAudioPlayer({ behaviors: { noSubscriber: voice.NoSubscriberBehavior.Play } });
    player.play(resource);
    connection.subscribe(player);
    state.player = player;
    log('Silent audio stream started');
  } catch (error) {
    log('Silent audio unavailable (is ffmpeg installed?):', error.message);
  }
}

function destroyConnection() {
  if (state.reconnectTimer) {
    clearTimeout(state.reconnectTimer);
    state.reconnectTimer = null;
  }
  if (state.player) {
    try {
      state.player.stop();
    } catch {
      /* ignore */
    }
    state.player = null;
  }
  if (state.connection) {
    try {
      state.connection.destroy();
    } catch {
      /* ignore */
    }
    state.connection = null;
  }
}

function waitForConnectionState(connection, timeout = 10000) {
  return new Promise((resolve) => {
    const finish = (result) => {
      clearTimeout(timer);
      resolve(result);
    };
    const timer = setTimeout(() => finish({ ok: false, reason: 'timed out' }), timeout);
    connection.on('stateChange', (oldState, newState) => {
      if (newState.status === voice.VoiceConnectionStatus.Ready) {
        finish({ ok: true });
      } else if (newState.status === voice.VoiceConnectionStatus.Destroyed) {
        finish({ ok: false, reason: 'connection was rejected' });
      }
    });
    if (connection.state.status === voice.VoiceConnectionStatus.Ready) {
      finish({ ok: true });
    }
  });
}

function reportJoinResult(interaction, connection, channelName, verb) {
  waitForConnectionState(connection, 20000).then((result) => {
    const message = result.ok
      ? `${verb} **${channelName}**.`
      : `Could not connect to **${channelName}** (${result.reason}). Check the console and the channel permissions.`;
    interaction.editReply(message).catch((error) => log('Could not update reply:', error.message));
  });
}

async function joinChannel(guild, channel, reason = 'command') {
  const existing = voice.getVoiceConnection(guild.id);
  if (existing) {
    const reusable = [
      voice.VoiceConnectionStatus.Signalling,
      voice.VoiceConnectionStatus.Connecting,
      voice.VoiceConnectionStatus.Ready,
      voice.VoiceConnectionStatus.Reconnecting,
    ].includes(existing.state.status);
    if (reusable && existing.joinConfig.channelId === channel.id) {
      log(`Already in ${channel.name}`);
      return existing;
    }
    destroyConnection();
    try {
      existing.destroy();
    } catch {
      /* ignore */
    }
  }

  const me = guild.members.me;
  const perms = channel.permissionsFor(me);
  if (perms && !perms.has(PermissionFlagsBits.Connect)) {
    throw new Error(`I lack the **Connect** permission in **${channel.name}**.`);
  }

  const connection = voice.joinVoiceChannel({
    channelId: channel.id,
    guildId: guild.id,
    adapterCreator: guild.voiceAdapterCreator,
    selfMute: CONFIG.selfMute,
    selfDeaf: false,
  });

  state.guildId = guild.id;
  state.channelId = channel.id;
  state.channelName = channel.name;
  state.connection = connection;
  state.intentionalLeave = false;
  saveState();

  connection.on('stateChange', (oldState, newState) => {
    if (newState.status === voice.VoiceConnectionStatus.Disconnected) {
      log('Voice connection dropped, scheduling rejoin');
      scheduleRejoin(guild.id, state.channelId ?? channel.id, 5000);
    }
    if (newState.status === voice.VoiceConnectionStatus.Destroyed) {
      log('Voice connection destroyed');
    }
  });

  connection.on('error', (error) => {
    log('Voice connection error:', error.message);
  });

  startSilentAudio(connection);
  log(`Joined **${channel.name}** in **${guild.name}** (${reason})`);
  return connection;
}

function scheduleRejoin(guildId, channelId, delay = 5000) {
  if (state.reconnectTimer) clearTimeout(state.reconnectTimer);
  state.attempts += 1;
  const backoff = Math.min(delay * state.attempts, 60000);
  log(`Rejoining in ${Math.round(backoff / 1000)}s (attempt ${state.attempts})`);
  state.reconnectTimer = setTimeout(async () => {
    state.reconnectTimer = null;
    if (state.intentionalLeave) return;
    const guild = client.guilds.cache.get(guildId);
    if (!guild) return;
    const channel = guild.channels.cache.get(channelId);
    if (!channel) {
      log(`Channel ${channelId} no longer exists`);
      clearState();
      return;
    }
    const existing = voice.getVoiceConnection(guildId);
    if (
      existing &&
      existing.state.status === voice.VoiceConnectionStatus.Ready &&
      existing.joinConfig.channelId === channelId
    ) {
      log('Connection recovered on its own, staying in the channel');
      state.attempts = 0;
      return;
    }
    try {
      await joinChannel(guild, channel, 'rejoin');
      state.attempts = 0;
    } catch (error) {
      log('Rejoin failed:', error.message);
      scheduleRejoin(guildId, channelId, 5000);
    }
  }, backoff);
}

async function leaveChannel(reason = 'command') {
  state.intentionalLeave = true;
  destroyConnection();
  clearState();
  log(`Left the voice channel (${reason})`);
}

async function resolveChannel(guild, member, channelOption) {
  if (channelOption) {
    const channel = await guild.channels.fetch(channelOption.id).catch(() => null);
    if (!channel) throw new Error('That channel no longer exists.');
    if (![ChannelType.GuildVoice, ChannelType.GuildStageVoice].includes(channel.type)) {
      throw new Error('That is not a voice channel.');
    }
    return channel;
  }

  const current = member?.voice?.channel ?? guild.voiceStates?.cache?.get(member?.id)?.channel;
  if (current) return current;

  if (CONFIG.vcChannelId) {
    const configured = await guild.channels.fetch(CONFIG.vcChannelId).catch(() => null);
    if (configured && [ChannelType.GuildVoice, ChannelType.GuildStageVoice].includes(configured.type)) {
      return configured;
    }
  }

  const fallback = guild.channels.cache.find(
    (channel) =>
      [ChannelType.GuildVoice, ChannelType.GuildStageVoice].includes(channel.type) &&
      channel.permissionsFor(guild.members.me)?.has(PermissionFlagsBits.Connect),
  );
  if (!fallback) throw new Error('No voice channel found that I can connect to.');
  return fallback;
}

const commands = [
  new SlashCommandBuilder()
    .setName('vc')
    .setDescription('Control where the bot sits in voice')
    .addSubcommand((sub) =>
      sub
        .setName('join')
        .setDescription('Join a voice channel (defaults to your channel)')
        .addChannelOption((option) =>
          option
            .setName('channel')
            .setDescription('Voice channel to join')
            .addChannelTypes(ChannelType.GuildVoice, ChannelType.GuildStageVoice),
        ),
    )
    .addSubcommand((sub) => sub.setName('leave').setDescription('Remove the bot from the voice channel'))
    .addSubcommand((sub) => sub.setName('status').setDescription('Show the current voice status'))
    .addSubcommand((sub) =>
      sub
        .setName('move')
        .setDescription('Move the bot to another voice channel')
        .addChannelOption((option) =>
          option
            .setName('channel')
            .setDescription('Voice channel to move into')
            .addChannelTypes(ChannelType.GuildVoice, ChannelType.GuildStageVoice),
        ),
    ),
];

const client = new Client({
  intents: [GatewayIntentBits.Guilds, GatewayIntentBits.GuildVoiceStates],
});

let commandsRegistered = false;

async function registerCommands() {
  try {
    const { REST, Routes } = require('discord.js');
    const rest = new REST({ version: '10' }).setToken(CONFIG.token);
    const body = commands.map((command) => command.toJSON());
    if (CONFIG.guildId) {
      await rest.put(Routes.applicationGuildCommands(client.user.id, CONFIG.guildId), { body });
      log(`Registered ${body.length} command(s) for guild ${CONFIG.guildId}`);
    } else {
      await rest.put(Routes.applicationCommands(client.user.id), { body });
      log(`Registered ${body.length} global command(s) (can take up to 1h to appear)`);
    }
  } catch (error) {
    log('Command registration failed:', error.message);
  }
}

client.on(Events.ClientReady, async (readyClient) => {
  log(`Logged in as ${readyClient.user.tag} (application ${readyClient.user.id})`);
  log(`Guilds available: ${[...readyClient.guilds.cache.values()].map((g) => `${g.name} (${g.id})`).join(', ') || 'none'}`);
  if (!commandsRegistered) {
    commandsRegistered = true;
    await registerCommands();
  }

  const saved = loadState();
  const targetGuildId = CONFIG.guildId ?? saved?.guildId ?? null;
  const targetChannelId = CONFIG.vcChannelId ?? saved?.channelId ?? null;

  if (!targetGuildId || !targetChannelId) {
    log('No saved channel configured. Use /vc join to place me in a voice channel.');
    log('Tip: set GUILD_ID and VC_CHANNEL_ID in .env to auto-join at startup.');
    return;
  }

  const guild = readyClient.guilds.cache.get(targetGuildId);
  if (!guild) {
    log(`Guild ${targetGuildId} is not available. Check that GUILD_ID is your server's ID and that the bot has been invited.`);
    log(`Available guilds: ${[...readyClient.guilds.cache.keys()].join(', ') || 'none'}`);
    return;
  }
  const channel = await guild.channels.fetch(targetChannelId).catch(() => null);
  if (!channel) {
    log(`Channel ${targetChannelId} was not found in ${guild.name}. Copy the channel ID again (right-click the voice channel -> Copy Channel ID).`);
    clearState();
    return;
  }
  try {
    const connection = await joinChannel(guild, channel, 'startup');
    const result = await waitForConnectionState(connection, 15000);
    if (result.ok) {
      log(`Startup join confirmed: I am live in **${channel.name}**`);
    } else {
      log(`Startup join did not complete (${result.reason}).`);
    }
  } catch (error) {
    log('Startup join failed:', error.stack ?? error.message);
  }
});

client.on(Events.InteractionCreate, async (interaction) => {
  if (!interaction.isChatInputCommand()) return;

  const sub = interaction.options.getSubcommand(false);
  log(
  `Interaction: /${interaction.commandName} ${sub ?? '(none)'} from ${interaction.user?.tag ?? 'unknown'} (${interaction.user?.id ?? 'no-id'})`,
);

  if (!userAllowed(interaction.user)) {
    const allowed = CONFIG.allowedUsers.join(', ');
    await interaction
      .reply({
        content: `You are not allowed to use this bot. Allowed user IDs: ${allowed}`,
        ephemeral: true,
      })
      .catch(() => {});
    return;
  }

  const guild = interaction.guild;
  const member = interaction.member;

  try {
    await interaction.deferReply();
  } catch (error) {
    log('Could not defer reply:', error.message);
    return;
  }

  try {
    if (interaction.commandName !== 'vc') {
      await interaction.editReply('Unknown command.');
      return;
    }

    if (sub === 'join') {
      const channel = await resolveChannel(guild, member, interaction.options.getChannel('channel'));
      const connection = await joinChannel(guild, channel, 'command');
      await interaction.editReply(`Joining **${channel.name}**...`);
      reportJoinResult(interaction, connection, channel.name, 'Sitting in');
      return;
    }

    if (sub === 'leave') {
      if (!state.channelId) {
        await interaction.editReply('I am not in a voice channel right now.');
        return;
      }
      const name = state.channelName ?? 'the voice channel';
      await leaveChannel('command');
      await interaction.editReply(`Removed from **${name}**.`);
      return;
    }

    if (sub === 'move') {
      const channel = interaction.options.getChannel('channel');
      const target = await resolveChannel(guild, member, channel);
      if (!target) throw new Error('That channel no longer exists.');
      const connection = await joinChannel(guild, target, 'move');
      await interaction.editReply(`Moving to **${target.name}**...`);
      reportJoinResult(interaction, connection, target.name, 'Moved to');
      return;
    }

    if (sub === 'status') {
      const embed = new EmbedBuilder()
        .setColor(0x5865f2)
        .addFields(
          {
            name: 'In voice',
            value: state.channelId ? `Yes - **${state.channelName}**` : 'No',
            inline: true,
          },
          {
            name: 'Server',
            value: state.guildId ? guild.name : '-',
            inline: true,
          },
          {
            name: 'Connection',
            value: state.connection ? state.connection.state.status : 'none',
            inline: true,
          },
          {
            name: 'Auto rejoin',
            value: CONFIG.rejoinOnKick ? 'On' : 'Off',
            inline: true,
          },
        );
      await interaction.editReply({ embeds: [embed] });
      return;
    }

    await interaction.editReply('Unknown subcommand. Try `/vc join`, `/vc leave`, `/vc move` or `/vc status`.');
  } catch (error) {
    log('Command error:', error.stack ?? error.message);
    const content = error.message ?? 'Something went wrong.';
    try {
      if (interaction.deferred) {
        await interaction.editReply({ content }).catch(async () => {
          await interaction.followUp({ content, ephemeral: true }).catch(() => {});
        });
      } else {
        await interaction.reply({ content, ephemeral: true }).catch(() => {});
      }
    } catch {
      log('Could not deliver the error reply');
    }
  }
});

client.on(Events.VoiceStateUpdate, (oldVoiceState, newVoiceState) => {
  if (newVoiceState.id !== client.user.id) return;

  const guild = newVoiceState.guild;
  const wasIn = oldVoiceState.channelId;
  const nowIn = newVoiceState.channelId;

  if (wasIn && !nowIn) {
    if (state.intentionalLeave) {
      log('Left the voice channel as requested');
      return;
    }
    if (!CONFIG.rejoinOnKick) {
      log('I was removed from the voice channel and auto rejoin is off');
      clearState();
      return;
    }
    log('I was removed from the voice channel, rejoining');
    scheduleRejoin(guild.id, wasIn, 3000);
    return;
  }

  if (nowIn && wasIn && nowIn !== wasIn) {
    log(`I was moved to channel ${nowIn}`);
    state.channelId = nowIn;
    state.channelName = guild.channels.cache.get(nowIn)?.name ?? null;
    saveState();
    const connection = voice.getVoiceConnection(guild.id);
    if (connection && connection.joinConfig.channelId !== nowIn) {
      destroyConnection();
      const channel = guild.channels.cache.get(nowIn);
      if (channel) {
        joinChannel(guild, channel, 'moved').catch((error) => log('Rejoin after move failed:', error.message));
      }
    }
  }
});

client.on(Events.GuildDelete, (guild) => {
  if (state.guildId === guild.id) {
    destroyConnection();
    clearState();
  }
});

client.on(Events.Error, (error) => log('Client error:', error.stack ?? error.message));
client.on(Events.Warn, (warning) => log('Client warning:', warning));

client.on(Events.Debug, (message) => {
  if (process.env.DEBUG === 'true') log('debug:', message);
});

process.on('unhandledRejection', (reason) => {
  log('Unhandled rejection:', reason?.stack ?? reason?.message ?? reason);
});

process.on('uncaughtException', (error) => {
  log('Uncaught exception (continuing):', error?.stack ?? error?.message ?? error);
});

async function shutdown(signal) {
  log(`Received ${signal}, shutting down`);
  try {
    await leaveChannel('shutdown');
  } catch {
    /* ignore */
  }
  client.destroy();
  process.exit(0);
}

process.on('SIGINT', () => shutdown('SIGINT'));
process.on('SIGTERM', () => shutdown('SIGTERM'));

if (!CONFIG.token) {
  log('DISCORD_TOKEN is missing. Copy .env.example to .env and fill it in.');
  process.exit(1);
}

const nodeMajor = Number(process.versions.node.split('.')[0]);
const nodeMinor = Number(process.versions.node.split('.')[1]);
if (nodeMajor < 22 || (nodeMajor === 22 && nodeMinor < 12)) {
  log(`Node ${process.versions.node} is too old. @discordjs/voice needs Node 22.12.0 or newer.`);
  log('Set the runtime to Node 22 (or 24) in your host\'s settings, then restart.');
  process.exit(1);
}

client.login(CONFIG.token).catch((error) => {
  log('Login failed:', error.message);
  if (/401|unauthorized|token/i.test(error.message)) {
    log('Your token looks wrong. Reset it in the Discord Developer Portal and update .env (no quotes, no spaces).');
  }
  process.exit(1);
});
