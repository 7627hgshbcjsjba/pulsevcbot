#!/usr/bin/env bash
# Termux (Android) setup for the Discord VC Bot.
# Run from the project folder already unzipped in Termux.
set -euo pipefail

echo "==> Checking Node.js version"
node_major=0
if command -v node >/dev/null 2>&1; then
  node_major="$(node -v | cut -d. -f1 | tr -dc '0-9')"
fi
if [ "$node_major" -lt 22 ]; then
  echo "    Node $(node -v) is too old (@discordjs/voice needs >= 22.12)"
  echo "    Run: pkg install nodejs -y"
  exit 1
fi
echo "    Node $(node -v) OK"

echo "==> Installing dependencies"
npm install --omit=dev --no-audit --no-fund

if [ ! -f .env ]; then
  echo "==> Creating .env"
  cp .env.example .env
  echo "    Edit .env and set DISCORD_TOKEN, GUILD_ID and VC_CHANNEL_ID"
fi

echo "==> Installing pm2"
npm install -g pm2

echo "==> Starting the bot"
pm2 delete vc-bot >/dev/null 2>&1 || true
pm2 start index.js --name vc-bot
pm2 save

echo "==> Requesting a wake lock so Android does not kill Termux"
termux-wake-lock 2>/dev/null || echo "    (install Termux:API to enable wake locks)"

cat <<'EOF'

Done.

  Logs        : pm2 logs vc-bot
  Restart     : pm2 restart vc-bot
  Stop        : pm2 stop vc-bot
  Start again : pm2 start vc-bot

Auto-start on reboot: install the "Termux:Boot" app from F-Droid,
then run:  pm2 startup   and follow the printed command.

Keep the phone plugged in to a charger.
EOF
