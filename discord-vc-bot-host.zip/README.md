# Discord VC Bot

A Discord bot that joins a voice channel and parks there indefinitely until you remove it with `/vc leave`.

## Hosting

To keep it online 24/7 without your PC running:

- **[HOSTING.md](./HOSTING.md)** - Oracle Cloud / Google Cloud (needs a card, $0 charged)
- **[HOSTING-NO-CARD.md](./HOSTING-NO-CARD.md)** - Android + Termux, an old PC, or community free VPS (no card needed)

Both come with a one-command deploy script.

## How it works

The bot holds a real Discord voice connection. `@discordjs/voice` sends a UDP keepalive packet every 5 seconds, so the connection stays alive indefinitely with **no audio encoder and no ffmpeg dependency**. The bot sits in the channel muted.

## Setup

1. **Create the application**
   - Go to https://discord.com/developers/applications -> New Application
   - Add a Bot, copy its token

2. **Configure the bot**
   - No privileged gateway intents are required (`Guild Voice States` is not privileged).
   - Under **Bot -> Permissions**, enable `Connect`, `Speak`, `Use Voice Activity`, and `View Channel`
   - Invite it: `https://discord.com/api/oauth2/authorize?client_id=YOUR_CLIENT_ID&permissions=3408896&scope=bot%20applications.commands`
     (permissions `3408896` = View Channel + Connect + Speak + Use Voice Activity)

3. **Set the environment**
   ```bash
   copy .env.example .env
   ```
   Fill in `DISCORD_TOKEN`. Optionally set `GUILD_ID` and `VC_CHANNEL_ID` to auto-join on startup, and `ALLOWED_USERS` to restrict who can control the bot.

4. **Run**
   ```bash
   npm install
   npm start
   ```

## Commands

| Command | Description |
| --- | --- |
| `/vc join [channel]` | Join a voice channel. Defaults to the channel you are in. |
| `/vc leave` | Remove the bot from the voice channel. |
| `/vc move <channel>` | Move the bot to a different voice channel. |
| `/vc status` | Show where the bot is and its connection state. |

Commands are registered automatically on startup. To register them manually (guild-scoped, instant): `npm run register` with `GUILD_ID` set.

## Behaviour

- The bot **auto-rejoins** if it is disconnected or dragged out of the channel (set `REJOIN_ON_KICK=false` to disable).
- Position is saved to `state.json`, so it rejoins the same channel after a restart.
- `/vc leave` is a deliberate exit, so it will not be undone by the auto-rejoin logic.
- If the bot is moved by a moderator, it follows to the new channel.

## Troubleshooting

- **Bot stays in channel but shows as disconnected**: check the console log. Discord sometimes requires the `Connect` permission plus `Use Voice Activity`.
- **Commands not appearing**: global commands can take up to an hour. Set `GUILD_ID` in `.env` for instant guild-scoped registration.
- **Nothing happens on `/vc join`**: verify the bot has `Connect` permission on that specific channel.
